import { useState, useEffect } from 'react';
import { 
  FaSyncAlt, FaEye, FaMapMarkerAlt, 
  FaCalendarAlt, FaCamera, FaVideo, 
  FaImage, FaChevronLeft, FaChevronRight, FaTimes, FaPlus, FaFileInvoice, FaSave, FaFilePdf, FaFileExcel, FaDownload, FaUser, FaTrash, FaCheckCircle
} from 'react-icons/fa';
import './Incidentes.css';
import Swal from 'sweetalert2';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import ExcelJS from 'exceljs';
import logo from './assets/jurp.png';
import refAltura from './assets/ref_altura.png';
import refAncho from './assets/ref_ancho.png';
import MantenedorEquipos from './MantenedorEquipos';

function Incidentes() {
  const [incidentes, setIncidentes] = useState([]);
  const [cargando, setCargando] = useState(true);
  const [paginaActual, setPaginaActual] = useState(1);
  const itemsPorPagina = 8;

  // --- CATÁLOGOS (mantenedores) ---
  const [catEquipos, setCatEquipos] = useState([]);
  const [catMarcas, setCatMarcas] = useState([]);
  const [catModelos, setCatModelos] = useState([]);
  const [catActividades, setCatActividades] = useState([]);
  const [mantenedorAbierto, setMantenedorAbierto] = useState(false);

  // --- ESTADOS DEL MODAL PRINCIPAL ---
  const [modalAbierto, setModalAbierto] = useState(false);
  const [incidenteActivo, setIncidenteActivo] = useState(null);
  const [recursos, setRecursos] = useState([]); 
  const [guardando, setGuardando] = useState(false);

  // --- ESTADOS DEL MODAL PDF ---
  const [modalPdfAbierto, setModalPdfAbierto] = useState(false);
  const [pdfUrlActivo, setPdfUrlActivo] = useState(null);
  const [imgRefModal, setImgRefModal] = useState(null);   // {src, titulo} o null

  // --- ESTADOS DEL MODAL DE EVIDENCIAS (GALERÍA) ---
  const [modalMediaAbierto, setModalMediaAbierto] = useState(false);
  const [galeriaMedia, setGaleriaMedia] = useState([]);
  const [galeriaIndex, setGaleriaIndex] = useState(0);
  const [cargandoMedia, setCargandoMedia] = useState(false);
  const [galeriaIncidente, setGaleriaIncidente] = useState(null);

  const getFechaHoy = () => {
    const hoy = new Date();
    return hoy.toISOString().split('T')[0];
  };

  const generarCorrelativo = () => {
    // Placeholder mientras el backend responde con el correlativo real.
    const fecha = new Date();
    const strFecha = `${fecha.getFullYear()}${String(fecha.getMonth()+1).padStart(2,'0')}${String(fecha.getDate()).padStart(2,'0')}`;
    return `PD-____-${strFecha}`;
  };
  
  const estadoInicialRecurso = {
    tipo: 'Personal', descripcion: '', cantidad: 1, precioUnitario: 0,
    numPersonas: 1, horasTrabajo: 8, horasExtras: 0, 
    horasEfectivas: '', obsReduccion: '',
    numeroParte: generarCorrelativo(), 
    fechaParte: getFechaHoy(), 
    turno: 'Día', zonaTrabajo: '',
    proveedor: '', operador: '', licencia: '', categoria: '', longitud: '',
    equipoId: '', equipo: '',
    origen: 'JURP',
    marcaId: '', marca: '',
    modeloId: '', placa: '', modeloMaquina: '', codigoMaquina: '',
    hmInicio: '', hmFin: '', combustible: '', vale: '', fotoVale: null,
    actividad: '', observaciones: '', fotoParte: null,
    incluirMetrado: false, longitud: '', altura: '', anchoSup: '', anchoInf: ''
  };
  const [nuevoRecurso, setNuevoRecurso] = useState(estadoInicialRecurso);

  // ── Carga de catálogos (equipos/marcas/modelos) ──────────────────────────
  // Mismo backend que el resto del módulo operations. Sin token: los endpoints
  // son AllowAny, y mandar un token vencido provoca 401 (igual que la maquinaria,
  // que también llama sin Authorization).
  const API_OPS = 'https://gideonstudio.duckdns.org/api/v1/mobile/operations';

  const cargarEquiposCat = async (origen) => {
    try {
      const r = await fetch(`${API_OPS}/equipos/?activo=true&origen=${origen}`);
      if (r.ok) setCatEquipos(await r.json());
    } catch (e) { console.error(e); }
  };
  const cargarMarcasCat = async (equipoId) => {
    if (!equipoId) { setCatMarcas([]); return; }
    try {
      const r = await fetch(`${API_OPS}/marcas/?activo=true&equipo=${equipoId}`);
      if (r.ok) setCatMarcas(await r.json());
    } catch (e) { console.error(e); }
  };
  const cargarModelosCat = async (marcaId) => {
    if (!marcaId) { setCatModelos([]); return; }
    try {
      // Solo placas disponibles (estado=0) para el parte diario.
      const r = await fetch(`${API_OPS}/modelos/?activo=true&estado=0&marca=${marcaId}`);
      if (r.ok) setCatModelos(await r.json());
    } catch (e) { console.error(e); }
  };

  // Al montar, carga los equipos del origen inicial (JURP).
  useEffect(() => { cargarEquiposCat(nuevoRecurso.origen); }, []);

  // Carga el catálogo de actividades (para el combo del parte diario).
  const cargarActividades = async () => {
    try {
      const r = await fetch(`${API_OPS}/actividades/?activo=true`);
      if (r.ok) setCatActividades(await r.json());
    } catch (e) { console.error(e); }
  };
  useEffect(() => { cargarActividades(); }, []);

  // Pide al backend el siguiente N° de parte (PD-XXXX-AAAAMMDD, reinicia por año).
  const obtenerCorrelativoParte = async () => {
    try {
      const r = await fetch(`${API_OPS}/daily-part-heavy-equipments/siguiente-correlativo/`);
      if (r.ok) {
        const data = await r.json();
        if (data?.numero_parte) {
          setNuevoRecurso(prev => ({ ...prev, numeroParte: data.numero_parte }));
        }
      }
    } catch (e) { console.error(e); }
  };
  useEffect(() => { obtenerCorrelativoParte(); }, []);

  // Handlers de los selects encadenados: Origen → Equipo → Marca → Placa.
  const onCambiaOrigen = (origen) => {
    // El origen es el primer filtro: recarga equipos y limpia toda la cadena.
    setNuevoRecurso(prev => ({ ...prev, origen, equipoId: '', equipo: '', marcaId: '', marca: '', modeloId: '', placa: '', modeloMaquina: '', codigoMaquina: '' }));
    setCatMarcas([]); setCatModelos([]);
    cargarEquiposCat(origen);
  };
  const onCambiaEquipo = (id) => {
    const eq = catEquipos.find(e => String(e.id) === String(id));
    setNuevoRecurso(prev => ({ ...prev, equipoId: id, equipo: eq?.nombre || '', marcaId: '', marca: '', modeloId: '', placa: '', modeloMaquina: '', codigoMaquina: '' }));
    setCatMarcas([]); setCatModelos([]);
    cargarMarcasCat(id);
  };
  const onCambiaMarca = (id) => {
    const ma = catMarcas.find(m => String(m.id) === String(id));
    setNuevoRecurso(prev => ({ ...prev, marcaId: id, marca: ma?.nombre || '', modeloId: '', placa: '', modeloMaquina: '', codigoMaquina: '' }));
    setCatModelos([]);
    cargarModelosCat(id);
  };
  const onCambiaModelo = (id) => {
    const mo = catModelos.find(m => String(m.id) === String(id));
    setNuevoRecurso(prev => ({ ...prev, modeloId: id, placa: mo?.placa || '', modeloMaquina: mo?.modelo || '', codigoMaquina: mo?.codigo || '' }));
  };

  // Maneja el combo de actividad. Si elige "__OTRO__", pide el nombre, lo
  // guarda en el catálogo y lo selecciona.
  const onCambiaActividad = async (valor) => {
    if (valor === '__OTRO__') {
      const { value: nombre } = await Swal.fire({
        title: 'Nueva actividad',
        input: 'text',
        inputPlaceholder: 'Ej. RIEGO DE PLATAFORMA',
        showCancelButton: true,
        confirmButtonText: 'Agregar',
        inputValidator: (v) => !v && 'Escribe el nombre de la actividad',
      });
      if (!nombre) return;
      const limpio = nombre.toUpperCase().trim();
      try {
        const r = await fetch(`${API_OPS}/actividades/`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ nombre: limpio, activo: true }),
        });
        if (r.ok) {
          await cargarActividades();          // refresca el combo con la nueva
          setNuevoRecurso(prev => ({ ...prev, actividad: limpio }));
        } else {
          const e = await r.json();
          Swal.fire('Error', e.nombre ? e.nombre[0] : 'No se pudo crear la actividad.', 'error');
        }
      } catch (e) {
        Swal.fire('Error', 'Fallo de conexión al crear la actividad.', 'error');
      }
    } else {
      setNuevoRecurso(prev => ({ ...prev, actividad: valor }));
    }
  };

  const obtenerIncidentes = async () => {
    const token = localStorage.getItem('userToken'); 
    if (!token) return;
    setCargando(true);
    try {
      const res = await fetch('/api/v1/mobile/hi-incidents/list/', { 
        headers: { 'Content-Type': 'application/json', 'Authorization': `Token ${token}` } 
      });
      if (res.ok) {
        const data = await res.json();
        const tiposMapa = { '1': 'Deslizamiento', '2': 'Obstrucción', '3': 'Falla Mecánica', '4': 'Robo', '5': 'Daño Estructural', '6': 'Otro' };
        const listaFormateada = (data.results || []).map(inc => {
          let tipoNombre = tiposMapa[inc.type?.toString()] || 'Incidente';
          const anotherType = inc.another_type?.trim();
          if (anotherType && (tipoNombre === 'Otro' || tipoNombre === 'Otros')) tipoNombre = `Otro (${anotherType})`;
          return {
            id: inc.id, codigo: inc.code || 'Sin Código', lugar: inc.location_text || '-',
            tipo: tipoNombre, gravedad: inc.severity || 'lev', estado: inc.status || 'pat',
            usuario: inc.user?.username || 'Sistema',
            fecha: new Date(inc.created_at).toLocaleString('es-PE', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute:'2-digit' }),
            imagesCount: inc.images_count || 0, videosCount: inc.videos_count || 0,
            imagenUrl: inc.thumbnail || inc.image || null 
          };
        });
        setIncidentes(listaFormateada);
        setPaginaActual(1);
      }
    } catch (error) { console.error(error); } finally { setCargando(false); }
  };

  // ── Cargar thumbnails desde el detalle para cards sin imagen ───────────
  const cargarThumbnails = async (lista) => {
    const token = localStorage.getItem('userToken');
    if (!token) return;
    const sinThumb = lista.filter(i => !i.imagenUrl && (i.imagesCount > 0 || i.videosCount > 0));
    if (!sinThumb.length) return;

    const updates = {};
    await Promise.all(sinThumb.map(async (inc) => {
      try {
        const res = await fetch(`/api/v1/mobile/hi-incidents/${inc.id}/`, {
          headers: { 'Authorization': `Token ${token}`, 'Content-Type': 'application/json' }
        });
        if (res.ok) {
          const json = await res.json();
          const detail = json.data || json;
          const firstImg = (detail.images || [])[0];
          if (firstImg?.content) {
            updates[inc.id] = firstImg.content.startsWith('http') ? firstImg.content : `data:image/jpeg;base64,${firstImg.content}`;
          }
        }
      } catch (e) { /* silencioso */ }
    }));

    if (Object.keys(updates).length > 0) {
      setIncidentes(prev => prev.map(i => updates[i.id] ? { ...i, imagenUrl: updates[i.id] } : i));
    }
  };

  useEffect(() => {
    if (incidentes.length > 0) cargarThumbnails(incidentes);
  }, [incidentes.length]);

  // ── Cargar evidencias (imágenes y videos) de un incidente ──────────────
  const verEvidencias = async (inc) => {
    setGaleriaIncidente(inc);
    setGaleriaMedia([]);
    setGaleriaIndex(0);
    setCargandoMedia(true);
    setModalMediaAbierto(true);

    const token = localStorage.getItem('userToken');
    try {
      const res = await fetch(`/api/v1/mobile/hi-incidents/${inc.id}/`, {
        headers: { 'Authorization': `Token ${token}`, 'Content-Type': 'application/json' }
      });
      if (res.ok) {
        const json = await res.json();
        const detail = json.data || json;
        const media = [];
        (detail.images || []).forEach(it => {
          const src = it.content?.startsWith('http') ? it.content : `data:image/jpeg;base64,${it.content}`;
          media.push({ src, type: 'image' });
        });
        (detail.videos || []).forEach(it => {
          const src = it.content?.startsWith('http') ? it.content : `data:video/mp4;base64,${it.content}`;
          media.push({ src, type: 'video' });
        });
        if (media.length === 0 && inc.imagenUrl) {
          media.push({ src: inc.imagenUrl, type: 'image' });
        }
        setGaleriaMedia(media);
      }
    } catch (e) { console.error(e); } finally { setCargandoMedia(false); }
  };

  const galeriaAnterior = () => setGaleriaIndex(i => Math.max(0, i - 1));
  const galeriaSiguiente = () => setGaleriaIndex(i => Math.min(galeriaMedia.length - 1, i + 1));

  const cargarCosteosGuardados = async (incidenteId) => {
    const BASE_URL = 'https://gideonstudio.duckdns.org'; 
    try {
      const [resPers, resMat, resMaq] = await Promise.all([
        fetch(`${BASE_URL}/api/v1/mobile/operations/incident-personnels/`),
        fetch(`${BASE_URL}/api/v1/mobile/operations/incident-materials/`),
        fetch(`${BASE_URL}/api/v1/mobile/operations/daily-part-heavy-equipments/`)
      ]);
      const [dataPers, dataMat, dataMaq] = await Promise.all([resPers.json(), resMat.json(), resMaq.json()]);
      const listPers = Array.isArray(dataPers) ? dataPers : (dataPers.results || []);
      const listMat = Array.isArray(dataMat) ? dataMat : (dataMat.results || []);
      const listMaq = Array.isArray(dataMaq) ? dataMaq : (dataMaq.results || []);
      const idStr = String(incidenteId);
      const formatPers = listPers.filter(i => String(i.incident_report) === idStr).map(i => ({ idLocal: `db-pers-${i.id}`, dbId: i.id, endpoint: 'incident-personnels', tipo: 'Personal', descripcionResumen: i.description, cantidad: parseFloat(i.quantity_hours), precioUnitario: parseFloat(i.unit_price), total: parseFloat(i.quantity_hours) * parseFloat(i.unit_price), guardadoEnDB: true }));
      const formatMat = listMat.filter(i => String(i.incident_report) === idStr).map(i => ({ idLocal: `db-mat-${i.id}`, dbId: i.id, endpoint: 'incident-materials', tipo: 'Insumo', descripcionResumen: i.description, cantidad: parseFloat(i.quantity), precioUnitario: parseFloat(i.unit_price), total: parseFloat(i.quantity) * parseFloat(i.unit_price), guardadoEnDB: true }));
      const formatMaq = listMaq.filter(i => String(i.incident_report) === idStr).map(i => ({ idLocal: `db-maq-${i.id}`, dbId: i.id, endpoint: 'daily-part-heavy-equipments', cerrado: i.cerrado || false, tipo: 'Maquinaria', descripcionResumen: `Parte N° ${i.part_number} | ${i.equipment_name}\nActividad: ${i.activities}`, cantidad: Math.max(0, parseFloat(i.end_horometer) - parseFloat(i.start_horometer)), precioUnitario: parseFloat(i.unit_price), total: Math.max(0, parseFloat(i.end_horometer) - parseFloat(i.start_horometer)) * parseFloat(i.unit_price), guardadoEnDB: true }));
      setRecursos([...formatPers, ...formatMat, ...formatMaq]);
    } catch (error) { console.error("❌ Error al obtener los recursos guardados:", error); }
  };

  useEffect(() => { obtenerIncidentes(); }, []);

  const abrirModal = (inc) => {
    setIncidenteActivo(inc); setRecursos([]); 
    setNuevoRecurso({...estadoInicialRecurso, numeroParte: generarCorrelativo()});
    obtenerCorrelativoParte();
    setModalAbierto(true);
    cargarCosteosGuardados(inc.id); 
  };

  const abrirModalPdf = (dbId) => {
    const url = `https://gideonstudio.duckdns.org/api/v1/mobile/operations/daily-part-heavy-equipments/${dbId}/pdf/`;
    setPdfUrlActivo(url);
    setModalPdfAbierto(true);
  };

  // Elimina de la BASE DE DATOS uno o varios registros (para filas agrupadas).
  const eliminarRecursoGuardado = async (fila) => {
    // fila.registros = lista de {dbId, endpoint} que componen la fila agrupada.
    const registros = fila.registros || [{ dbId: fila.dbId, endpoint: fila.endpoint }];
    const cuantos = registros.length;
    const conf = await Swal.fire({
      title: '¿Eliminar?',
      text: cuantos > 1
        ? `Se eliminarán ${cuantos} registros de "${fila.descripcionResumen}" de forma permanente.`
        : `Se eliminará este recurso de forma permanente.`,
      icon: 'warning', showCancelButton: true, confirmButtonColor: '#d33',
      confirmButtonText: 'Sí, eliminar', cancelButtonText: 'Cancelar',
    });
    if (!conf.isConfirmed) return;

    const BASE_URL = 'https://gideonstudio.duckdns.org';
    try {
      const resultados = await Promise.all(registros.map(reg =>
        fetch(`${BASE_URL}/api/v1/mobile/operations/${reg.endpoint}/${reg.dbId}/`, {
          method: 'DELETE',
        })
      ));
      const okAll = resultados.every(r => r.ok || r.status === 204);
      if (okAll) {
        if (incidenteActivo) cargarCosteosGuardados(incidenteActivo.id);
        Swal.fire({ icon: 'success', title: 'Eliminado', timer: 1200, showConfirmButton: false });
      } else {
        const codigos = resultados.map(r => r.status).join(', ');
        Swal.fire('Error', `No se pudieron eliminar todos los registros (código: ${codigos}).`, 'error');
      }
    } catch (e) {
      Swal.fire('Error', 'Fallo de conexión al eliminar.', 'error');
    }
  };

  // Cierra un parte diario individual: libera su máquina y lo bloquea.
  const cerrarParteDiario = async (fila) => {
    const conf = await Swal.fire({
      title: '¿Finalizar actividades?',
      html: `Se cerrará este parte diario.<br>La máquina quedará <b>disponible</b> para otros partes y el parte <b>no podrá editarse</b>.`,
      icon: 'question', showCancelButton: true, confirmButtonColor: '#206bc4',
      confirmButtonText: 'Sí, finalizar', cancelButtonText: 'Cancelar',
    });
    if (!conf.isConfirmed) return;
    const BASE_URL = 'https://gideonstudio.duckdns.org';
    try {
      const r = await fetch(`${BASE_URL}/api/v1/mobile/operations/daily-part-heavy-equipments/${fila.dbId}/cerrar/`, { method: 'POST' });
      if (r.ok) {
        if (incidenteActivo) cargarCosteosGuardados(incidenteActivo.id);
        // Refresca el combo de placas leyendo el estado más reciente (evita
        // closures viejos). Si hay marca seleccionada, recarga sus placas.
        setNuevoRecurso(prev => {
          if (prev.marcaId) cargarModelosCat(prev.marcaId);
          return prev;
        });
        Swal.fire({ icon: 'success', title: 'Parte cerrado', text: 'La máquina fue liberada.', timer: 1500, showConfirmButton: false });
      } else {
        Swal.fire('Error', `No se pudo cerrar el parte (código: ${r.status}).`, 'error');
      }
    } catch (e) {
      Swal.fire('Error', 'Fallo de conexión al cerrar.', 'error');
    }
  };

  // Cierra la incidencia: cierra los partes (libera máquinas) Y cambia el
  // estado del incidente a "Cerrado" (status='cer').
  const cerrarIncidenteCompleto = async () => {
    if (!incidenteActivo) return;
    const conf = await Swal.fire({
      title: '¿Cerrar esta incidencia?',
      html: `Se cerrarán <b>todos los partes diarios</b> y sus máquinas quedarán disponibles.<br>El estado de la incidencia cambiará a <b>Cerrado</b>.`,
      icon: 'warning', showCancelButton: true, confirmButtonColor: '#2fb344',
      confirmButtonText: 'Sí, cerrar incidencia', cancelButtonText: 'Cancelar',
    });
    if (!conf.isConfirmed) return;
    const BASE_URL = 'https://gideonstudio.duckdns.org';
    const token = localStorage.getItem('userToken');
    try {
      // 1) Cerrar los partes diarios y liberar máquinas (backend de operaciones).
      const r = await fetch(`${BASE_URL}/api/v1/mobile/operations/incidentes/${incidenteActivo.id}/cerrar-partes/`, { method: 'POST' });
      if (!r.ok) {
        Swal.fire('Error', `No se pudieron cerrar los partes (código: ${r.status}).`, 'error');
        return;
      }
      // 2) Cambiar el estado del incidente a "Cerrado" (backend de incidentes).
      const rEstado = await fetch(`/api/v1/mobile/hi-incidents/${incidenteActivo.id}/`, {
        method: 'PATCH',
        headers: { 'Authorization': `Token ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'cer' }),
      });

      // Refrescos locales.
      cargarCosteosGuardados(incidenteActivo.id);
      setNuevoRecurso(prev => {
        if (prev.marcaId) cargarModelosCat(prev.marcaId);
        return prev;
      });

      if (rEstado.ok) {
        // Actualiza el badge en la lista sin recargar.
        setIncidentes(prev => prev.map(i => i.id === incidenteActivo.id ? { ...i, estado: 'cer' } : i));
        setIncidenteActivo(prev => prev ? { ...prev, estado: 'cer' } : prev);
        Swal.fire({ icon: 'success', title: 'Incidencia cerrada', text: 'Partes cerrados, máquinas liberadas y estado actualizado.', timer: 2200, showConfirmButton: false });
      } else {
        // Los partes se cerraron, pero el estado no se pudo cambiar.
        Swal.fire('Parcial', `Los partes se cerraron, pero no se pudo cambiar el estado de la incidencia (código: ${rEstado.status}). Revisa manualmente.`, 'warning');
      }
    } catch (e) {
      Swal.fire('Error', 'Fallo de conexión.', 'error');
    }
  };

  const horasMaquina = (nuevoRecurso.hmFin && nuevoRecurso.hmInicio) ? Math.max(0, (parseFloat(nuevoRecurso.hmFin) - parseFloat(nuevoRecurso.hmInicio))).toFixed(1) : 0;

  const volumenMetrado = nuevoRecurso.incluirMetrado ? (((parseFloat(nuevoRecurso.anchoSup)||0 + parseFloat(nuevoRecurso.anchoInf)||0) / 2) * (parseFloat(nuevoRecurso.altura)||0) * (parseFloat(nuevoRecurso.longitud)||0)).toFixed(2) : 0;

  const agregarRecurso = () => {
    let descFinal = nuevoRecurso.descripcion;
    let cantFinal = parseFloat(nuevoRecurso.cantidad) || 0;
    if (nuevoRecurso.tipo === 'Maquinaria') {
      const totalHM = parseFloat(horasMaquina) || 0;   // HM Fin - HM Inicio
      if (totalHM <= 0) return Swal.fire({ icon: 'warning', title: 'Atención', text: 'El Horómetro Final debe ser mayor al Inicial' });
      if (!nuevoRecurso.numeroParte) return Swal.fire({ icon: 'warning', title: 'Atención', text: 'El Número de Parte es obligatorio' });
      if (!nuevoRecurso.equipo) return Swal.fire({ icon: 'warning', title: 'Atención', text: 'Selecciona un equipo' });
      // Horas efectivas: por defecto = total del horómetro; editable.
      const efectivas = (nuevoRecurso.horasEfectivas === '' || nuevoRecurso.horasEfectivas === null)
        ? totalHM
        : parseFloat(nuevoRecurso.horasEfectivas) || 0;
      if (efectivas < 0 || efectivas > totalHM) return Swal.fire({ icon: 'warning', title: 'Atención', text: `Las Horas Efectivas deben estar entre 0 y ${totalHM}` });
      // Si hubo reducción, la observación es obligatoria.
      if (efectivas < totalHM && !nuevoRecurso.obsReduccion.trim()) {
        return Swal.fire({ icon: 'warning', title: 'Observación requerida', text: 'Detalla el motivo de la reducción de horas efectivas.' });
      }
      cantFinal = efectivas;   // el costo se calcula sobre las horas efectivas
      const equipoFinal = nuevoRecurso.equipo;
      const marcaFinal = nuevoRecurso.marca;
      descFinal = `Parte N° ${nuevoRecurso.numeroParte} | ${nuevoRecurso.codigoMaquina} · ${equipoFinal} ${marcaFinal} ${nuevoRecurso.modeloMaquina || ''} (${nuevoRecurso.placa})\n`;
      descFinal += `Zona: ${nuevoRecurso.zonaTrabajo} | Op: ${nuevoRecurso.operador} | Prov: ${nuevoRecurso.proveedor}\n`;
      descFinal += `HM: ${nuevoRecurso.hmInicio} a ${nuevoRecurso.hmFin} (${totalHM} HE) | Comb: ${nuevoRecurso.combustible || 0} Gls (Vale: ${nuevoRecurso.vale})\n`;
      descFinal += `Actividad: ${nuevoRecurso.actividad}`;
      if (efectivas < totalHM) {
        descFinal += `\nHoras efectivas: ${efectivas} HE (reducción de ${(totalHM - efectivas).toFixed(1)}). Motivo: ${nuevoRecurso.obsReduccion.trim()}`;
      }
      if (nuevoRecurso.incluirMetrado) descFinal += `\nVol. Extraído: ${volumenMetrado} m3`;
    } else if (nuevoRecurso.tipo === 'Personal') {
      const pers = parseInt(nuevoRecurso.numPersonas) || 0;
      const hrs = parseFloat(nuevoRecurso.horasTrabajo) || 0;
      const ext = parseFloat(nuevoRecurso.horasExtras) || 0;
      cantFinal = pers * (hrs + ext);
      if (!descFinal) return Swal.fire({ icon: 'warning', title: 'Atención', text: 'Ingresa el cargo (Ej. Peón)' });
      if (cantFinal <= 0) return Swal.fire({ icon: 'warning', title: 'Atención', text: 'Ingresa la cantidad de personas y horas' });
      descFinal = `${nuevoRecurso.descripcion}\n(Cuadrilla: ${pers} persona(s) x ${hrs}h normales + ${ext}h extras)`;
    } else {
      if (!descFinal) return Swal.fire({ icon: 'warning', title: 'Atención', text: 'Ingresa una descripción' });
    }
    const recursoCalculado = { ...nuevoRecurso, idLocal: Date.now(), descripcionResumen: descFinal, cantidad: cantFinal, precioUnitario: parseFloat(nuevoRecurso.precioUnitario) || 0, total: cantFinal * (parseFloat(nuevoRecurso.precioUnitario) || 0), guardadoEnDB: false };
    setRecursos([...recursos, recursoCalculado]);
    setNuevoRecurso({...estadoInicialRecurso, numeroParte: generarCorrelativo()});
    obtenerCorrelativoParte();
  };

  const eliminarRecurso = (idLocal) => setRecursos(recursos.filter(r => r.idLocal !== idLocal));
  // Elimina del estado local varios recursos (fila agrupada no guardada).
  const eliminarRecursosLocales = (idsLocales) => setRecursos(recursos.filter(r => !idsLocales.includes(r.idLocal)));
  const costoTotalIncidente = recursos.reduce((sum, item) => sum + item.total, 0);

  // Agrupa recursos idénticos (mismo tipo + detalle + precio) en una sola fila.
  // Maquinaria NO se agrupa: cada parte es único (tiene su PDF y horómetro propio).
  // Normaliza texto para comparar: minúsculas, sin tildes, espacios colapsados.
  const normalizar = (txt) => (txt || '')
    .toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')  // quita tildes
    .replace(/\s+/g, ' ')
    .trim();

  const recursosAgrupados = (() => {
    const grupos = new Map();
    for (const r of recursos) {
      const detalle = r.descripcionResumen || r.descripcion || '';
      let clave;
      if (r.tipo === 'Maquinaria') {
        // Agrupar maquinaria idéntica: misma máquina + actividad + precio.
        // Se ignora el N° de parte (único) y el estado de cierre. Texto normalizado.
        const detalleSinParte = detalle.replace(/Parte N° [^|]*\|/i, '').trim();
        clave = `maq|${normalizar(detalleSinParte)}|${r.precioUnitario}`;
      } else if (r.tipo === 'Personal') {
        // Agrupar personal por cargo + personas + horas + precio (ignora el motivo).
        const cargo = normalizar(r.descripcion);
        clave = `pers|${cargo}|${r.numPersonas}|${r.horasTrabajo}|${r.horasExtras}|${r.cantidad}|${r.precioUnitario}|${r.guardadoEnDB}`;
      } else {
        clave = `${r.tipo}|${normalizar(detalle)}|${r.precioUnitario}|${r.guardadoEnDB}`;
      }
      if (!grupos.has(clave)) {
        grupos.set(clave, {
          ...r,
          cantidadTotal: 0,
          totalSum: 0,
          count: 0,
          registros: [],   // {dbId, endpoint} de cada registro guardado del grupo
          idsLocales: [],  // idLocal de cada uno (para eliminar no-guardados)
          partesMaq: [],   // maquinaria: lista completa de partes del grupo (para PDF/Finalizar individual)
        });
      }
      const g = grupos.get(clave);
      g.cantidadTotal += r.cantidad;
      g.totalSum += r.total;
      g.count += 1;
      if (r.guardadoEnDB && r.dbId) g.registros.push({ dbId: r.dbId, endpoint: r.endpoint });
      g.idsLocales.push(r.idLocal);
      if (r.tipo === 'Maquinaria') {
        // Extraer el N° de parte del resumen para mostrarlo en cada botón.
        const mp = (r.descripcionResumen || '').match(/Parte N° ([^\s|]+)/i);
        g.partesMaq.push({ dbId: r.dbId, idLocal: r.idLocal, cerrado: r.cerrado, guardadoEnDB: r.guardadoEnDB, endpoint: r.endpoint, numeroParte: mp ? mp[1] : (r.numeroParte || ''), registro: r });
      }
    }
    return Array.from(grupos.values());
  })();

  // ── Helper: convertir imagen importada a base64 ────────────────────────
  const imgToBase64 = (src) => new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      canvas.getContext('2d').drawImage(img, 0, 0);
      resolve(canvas.toDataURL('image/png'));
    };
    img.onerror = () => resolve(null);
    img.src = src;
  });

  // ── Exportar PDF ──────────────────────────────────────────────────────
  const exportarPDF = async () => {
    if (!incidenteActivo) return;
    const doc = new jsPDF();
    const inc = incidenteActivo;
    const estadoTexto = inc.estado === 'pat' ? 'Pendiente' : inc.estado === 'ate' ? 'En Atención' : inc.estado === 'cer' ? 'Cerrado' : inc.estado;
    const gravedadTexto = inc.gravedad === 'lev' ? 'Leve' : inc.gravedad === 'mod' ? 'Moderada' : inc.gravedad === 'gra' ? 'Grave' : inc.gravedad;
    const fechaGenerado = new Date().toLocaleString('es-PE');

    doc.setFillColor(20, 99, 165);
    doc.rect(0, 0, 210, 30, 'F');
    const logoBase64 = await imgToBase64(logo);
    if (logoBase64) doc.addImage(logoBase64, 'PNG', 12, 4, 22, 22);
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(15); doc.setFont(undefined, 'bold');
    doc.text('JUNTA DE RIEGO PRESURIZADO', logoBase64 ? 38 : 14, 13);
    doc.setFontSize(10); doc.setFont(undefined, 'normal');
    doc.text('Reporte de Gestión de Incidente', logoBase64 ? 38 : 14, 20);
    doc.setFontSize(8);
    doc.text(`Generado: ${fechaGenerado}`, 196, 26, { align: 'right' });

    let y = 40;
    doc.setTextColor(30, 41, 59); doc.setFontSize(14); doc.setFont(undefined, 'bold');
    doc.text(inc.tipo, 14, y); y += 9;
    doc.setFontSize(9);
    const infoRows = [
      ['Código:', inc.codigo || 'Sin Código'],
      ['Ubicación:', inc.lugar || '-'],
      ['Fecha:', inc.fecha || '-'],
      ['Estado:', estadoTexto],
      ['Gravedad:', gravedadTexto],
      ['Reportado por:', inc.usuario || '-'],
    ];
    for (const [label, val] of infoRows) {
      doc.setFont(undefined,'bold'); doc.setTextColor(100,116,139); doc.text(label, 14, y);
      doc.setFont(undefined,'normal'); doc.setTextColor(30,41,59);
      const lines = doc.splitTextToSize(val, 140);
      doc.text(lines, 55, y);
      y += lines.length * 4.5 + 1.5;
    }
    y += 5; doc.setDrawColor(226,232,240); doc.line(14,y,196,y); y += 8;
    doc.setFontSize(11); doc.setFont(undefined,'bold'); doc.setTextColor(30,41,59);
    doc.text('Detalle de Recursos y Costeo', 14, y); y += 5;

    if (recursos.length > 0) {
      autoTable(doc, {
        startY: y,
        head: [['N°','Tipo','Detalle','Cantidad','Unidad','P. Unit. (S/)','Total (S/)']],
        body: recursos.map((r,i) => [i+1, r.tipo, (r.descripcionResumen||r.descripcion||'').replace(/\n/g,' '), r.cantidad.toFixed(2), r.tipo==='Personal'?'HH':r.tipo==='Maquinaria'?'HE':'Unid.', parseFloat(r.precioUnitario).toFixed(2), r.total.toFixed(2)]),
        foot: [['','','','','','COSTO TOTAL:',`S/ ${costoTotalIncidente.toFixed(2)}`]],
        styles:{fontSize:8,cellPadding:2.5,lineColor:[226,232,240],lineWidth:0.1},
        headStyles:{fillColor:[20,99,165],textColor:[255,255,255],fontStyle:'bold',fontSize:8},
        footStyles:{fillColor:[241,245,249],textColor:[30,41,59],fontStyle:'bold',fontSize:9},
        alternateRowStyles:{fillColor:[248,250,252]},
        margin:{left:14,right:14},
        columnStyles:{0:{cellWidth:10,halign:'center'},1:{cellWidth:20},2:{cellWidth:68},3:{cellWidth:18,halign:'right'},4:{cellWidth:14,halign:'center'},5:{cellWidth:24,halign:'right'},6:{cellWidth:28,halign:'right'}},
      });
    } else {
      doc.setFontSize(9); doc.setFont(undefined,'normal'); doc.setTextColor(100,116,139);
      doc.text('No hay recursos registrados para este incidente.', 14, y+6);
    }
    const pageCount = doc.internal.getNumberOfPages();
    for (let i=1;i<=pageCount;i++){doc.setPage(i);doc.setFontSize(7);doc.setTextColor(150);doc.text(`Página ${i} de ${pageCount} — Sistema Integrado de Monitoreo — JURP`,105,290,{align:'center'});}

    // Mostrar en modal
    const blobUrl = doc.output('bloburl');
    setPdfUrlActivo(blobUrl);
    setModalPdfAbierto(true);
  };

  // ── Exportar Excel (con logo y headers azules) ────────────────────────
  const exportarExcel = async () => {
    if (!incidenteActivo) return;
    const inc = incidenteActivo;
    const estadoTexto = inc.estado === 'pat' ? 'Pendiente' : inc.estado === 'ate' ? 'En Atención' : inc.estado === 'cer' ? 'Cerrado' : inc.estado;
    const gravedadTexto = inc.gravedad === 'lev' ? 'Leve' : inc.gravedad === 'mod' ? 'Moderada' : inc.gravedad === 'gra' ? 'Grave' : inc.gravedad;
    const fechaGenerado = new Date().toLocaleString('es-PE');

    const wb = new ExcelJS.Workbook();
    const ws = wb.addWorksheet('Reporte de Incidente');

    // Anchos de columna
    ws.columns = [
      { width: 20 }, { width: 16 }, { width: 45 }, { width: 14 }, { width: 10 }, { width: 16 }, { width: 16 }
    ];

    const azul = { type: 'pattern', pattern: 'solid', fgColor: { argb: '1463A5' } };
    const azulClaro = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'E0F2FE' } };
    const grisClaro = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'F1F5F9' } };
    const fuenteBlanca = { bold: true, color: { argb: 'FFFFFF' }, size: 12 };
    const fuenteBlancaSm = { bold: true, color: { argb: 'FFFFFF' }, size: 10 };
    const borde = { top:{style:'thin',color:{argb:'E2E8F0'}}, bottom:{style:'thin',color:{argb:'E2E8F0'}}, left:{style:'thin',color:{argb:'E2E8F0'}}, right:{style:'thin',color:{argb:'E2E8F0'}} };

    // Header azul (filas 1-3)
    for (let r = 1; r <= 3; r++) {
      for (let c = 1; c <= 7; c++) { ws.getCell(r, c).fill = azul; }
    }
    ws.getRow(1).height = 28;
    ws.getRow(2).height = 20;
    ws.getRow(3).height = 18;

    // Logo en A1 (ocupa A1:A3)
    try {
      const logoB64 = await imgToBase64(logo);
      if (logoB64) {
        const imgId = wb.addImage({ base64: logoB64.split(',')[1], extension: 'png' });
        ws.addImage(imgId, { tl: { col: 0, row: 0 }, ext: { width: 75, height: 65 } });
      }
    } catch(e) {}

    // Título en C1 (después del logo)
    ws.mergeCells('C1:G1');
    ws.getCell('C1').value = 'JUNTA DE RIEGO PRESURIZADO';
    ws.getCell('C1').font = fuenteBlanca;
    ws.getCell('C1').alignment = { vertical: 'middle' };

    ws.mergeCells('C2:G2');
    ws.getCell('C2').value = 'Reporte de Gestión de Incidente';
    ws.getCell('C2').font = fuenteBlancaSm;
    ws.getCell('C2').alignment = { vertical: 'middle' };

    ws.mergeCells('C3:G3');
    ws.getCell('C3').value = `Generado: ${fechaGenerado}`;
    ws.getCell('C3').font = { italic: true, size: 9, color: { argb: 'D0D5DD' } };
    ws.getCell('C3').alignment = { vertical: 'middle' };

    // Fila 4 vacía
    ws.getRow(4).height = 6;

    // Sección: Datos del incidente
    ws.mergeCells('A5:G5');
    ws.getCell('A5').value = 'DATOS DEL INCIDENTE';
    ws.getCell('A5').font = { bold: true, color: { argb: 'FFFFFF' }, size: 10 };
    ws.getCell('A5').fill = azul;
    ['B5','C5','D5','E5','F5','G5'].forEach(c => { ws.getCell(c).fill = azul; });
    ws.getRow(5).height = 22;

    const campos = [
      ['Tipo de Incidente', inc.tipo],
      ['Código', inc.codigo || 'Sin Código'],
      ['Ubicación', inc.lugar || '-'],
      ['Fecha', inc.fecha || '-'],
      ['Estado', estadoTexto],
      ['Gravedad', gravedadTexto],
      ['Reportado por', inc.usuario || '-'],
    ];
    campos.forEach(([label, val], i) => {
      const row = ws.getRow(6 + i);
      ws.getCell(`A${6+i}`).value = label;
      ws.getCell(`A${6+i}`).font = { bold: true, size: 9, color: { argb: '64748B' } };
      ws.getCell(`A${6+i}`).fill = grisClaro;
      ws.mergeCells(`B${6+i}:G${6+i}`);
      ws.getCell(`B${6+i}`).value = val;
      ws.getCell(`B${6+i}`).font = { size: 10 };
    });

    // Sección: Recursos
    const rStart = 14;
    ws.mergeCells(`A${rStart}:G${rStart}`);
    ws.getCell(`A${rStart}`).value = 'DETALLE DE RECURSOS Y COSTEO';
    ws.getCell(`A${rStart}`).font = { bold: true, color: { argb: 'FFFFFF' }, size: 10 };
    ws.getCell(`A${rStart}`).fill = azul;
    ['B','C','D','E','F','G'].forEach(c => { ws.getCell(`${c}${rStart}`).fill = azul; });
    ws.getRow(rStart).height = 22;

    // Header tabla
    const hRow = rStart + 1;
    ['N°','Tipo','Detalle','Cantidad','Unidad','P. Unit. (S/)','Total (S/)'].forEach((h, i) => {
      const cell = ws.getCell(hRow, i + 1);
      cell.value = h;
      cell.font = { bold: true, color: { argb: 'FFFFFF' }, size: 9 };
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: '3B82F6' } };
      cell.alignment = { horizontal: i >= 3 ? 'right' : 'left', vertical: 'middle' };
      cell.border = borde;
    });

    // Filas de datos
    recursos.forEach((r, i) => {
      const rowNum = hRow + 1 + i;
      const vals = [
        i + 1,
        r.tipo,
        (r.descripcionResumen || r.descripcion || '').replace(/\n/g, ' '),
        r.cantidad,
        r.tipo === 'Personal' ? 'HH' : r.tipo === 'Maquinaria' ? 'HE' : 'Unid.',
        parseFloat(r.precioUnitario),
        r.total,
      ];
      vals.forEach((v, j) => {
        const cell = ws.getCell(rowNum, j + 1);
        cell.value = v;
        cell.font = { size: 9 };
        cell.border = borde;
        if (j >= 3) cell.alignment = { horizontal: 'right' };
        if (j === 5 || j === 6) cell.numFmt = '#,##0.00';
        if (i % 2 === 1) cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'F8FAFC' } };
      });
    });

    // Fila total
    const totalRow = hRow + 1 + recursos.length + 1;
    ws.mergeCells(`A${totalRow}:E${totalRow}`);
    ws.getCell(`F${totalRow}`).value = 'COSTO TOTAL:';
    ws.getCell(`F${totalRow}`).font = { bold: true, size: 10 };
    ws.getCell(`F${totalRow}`).fill = azulClaro;
    ws.getCell(`F${totalRow}`).alignment = { horizontal: 'right' };
    ws.getCell(`G${totalRow}`).value = costoTotalIncidente;
    ws.getCell(`G${totalRow}`).font = { bold: true, size: 11 };
    ws.getCell(`G${totalRow}`).numFmt = '"S/ "#,##0.00';
    ws.getCell(`G${totalRow}`).fill = azulClaro;

    // Descargar
    const buffer = await wb.xlsx.writeBuffer();
    const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Reporte_Incidente_${inc.codigo || inc.id}_${new Date().toISOString().slice(0,10)}.xlsx`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const guardarCosteos = async () => {
    const recursosNuevos = recursos.filter(r => !r.guardadoEnDB);
    if (recursosNuevos.length === 0) return Swal.fire({ icon: 'info', title: 'Todo al día', text: 'No hay recursos nuevos.' });
    setGuardando(true);
    const BASE_URL = 'https://gideonstudio.duckdns.org'; 
    const token = localStorage.getItem('userToken'); 
    try {
      for (const r of recursosNuevos) {
        let endpoint = '';
        let formData = new FormData();
        formData.append('incident_report', incidenteActivo.id);
        if (r.tipo === 'Personal') {
          endpoint = `${BASE_URL}/api/v1/mobile/operations/incident-personnels/`;
          formData.append('description', r.descripcionResumen || r.descripcion); 
          formData.append('quantity_hours', r.cantidad);
          formData.append('unit_price', r.precioUnitario);
          // Desglose de la cuadrilla
          formData.append('num_personas', parseInt(r.numPersonas)||0);
          formData.append('horas_normales', parseFloat(r.horasTrabajo)||0);
          formData.append('horas_extras', parseFloat(r.horasExtras)||0);
        } else if (r.tipo === 'Insumo') {
          endpoint = `${BASE_URL}/api/v1/mobile/operations/incident-materials/`;
          formData.append('description', r.descripcion);
          formData.append('quantity', r.cantidad);
          formData.append('unit_price', r.precioUnitario);
        } else if (r.tipo === 'Maquinaria') {
          endpoint = `${BASE_URL}/api/v1/mobile/operations/daily-part-heavy-equipments/`;
          formData.append('part_number', r.numeroParte); formData.append('date', r.fechaParte);
          formData.append('shift', r.turno); formData.append('work_zone_text', r.zonaTrabajo);
          formData.append('provider', r.proveedor); formData.append('operator', r.operador);
          formData.append('licencia', r.licencia || ''); formData.append('categoria', r.categoria || '');
          if (r.longitud !== '' && r.longitud != null) formData.append('longitud', r.longitud);
          formData.append('equipment_name', r.equipo);
          formData.append('brand_name', r.marca);
          formData.append('model_plate', r.placa ? `${r.modeloMaquina || ''} / ${r.placa}`.trim() : (r.modeloMaquina || '')); formData.append('start_horometer', r.hmInicio);
          formData.append('end_horometer', r.hmFin); formData.append('fuel_gallons', r.combustible || 0);
          formData.append('fuel_voucher', r.vale); formData.append('activities', r.actividad);
          formData.append('observations', r.observaciones); formData.append('unit_price', r.precioUnitario);
          if (r.fotoParte) formData.append('part_photo', r.fotoParte);
          if (r.fotoVale) formData.append('voucher_photo', r.fotoVale);
          if (r.incluirMetrado) {
            if (r.anchoSup !== '' && r.anchoSup != null) formData.append('width_top', r.anchoSup);
            if (r.anchoInf !== '' && r.anchoInf != null) formData.append('width_bottom', r.anchoInf);
            if (r.altura !== '' && r.altura != null) formData.append('height', r.altura);
            if (r.longitud !== '' && r.longitud != null) formData.append('length', r.longitud);
          }
        }
        const res = await fetch(endpoint, { method: 'POST', body: formData });
        if (!res.ok) {
          let detalle = '';
          try { detalle = JSON.stringify(await res.json()); } catch (e) { detalle = `código ${res.status}`; }
          throw new Error(`Error al guardar ${r.tipo}: ${detalle}`);
        }
        // Si es maquinaria y se eligió una placa del catálogo, marcarla como
        // NO disponible (estado=1) para que no aparezca en otros partes.
        if (r.tipo === 'Maquinaria' && r.modeloId) {
          try {
            await fetch(`${BASE_URL}/api/v1/mobile/operations/modelos/${r.modeloId}/`, {
              method: 'PATCH',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ estado: 1 }),
            });
          } catch (e) { console.error('No se pudo actualizar disponibilidad de la máquina', e); }
        }
      }
      Swal.fire({ icon: 'success', title: 'Éxito', text: 'Se guardó correctamente', confirmButtonColor: '#206bc4' });
      setRecursos([]); setModalAbierto(false); 
    } catch (error) {
      console.error(error);
      Swal.fire({ icon: 'error', title: 'Error al guardar', text: error.message || 'Hubo un error al guardar en la base de datos.' });
    } finally { setGuardando(false); }
  };

  const indexUltimoItem = paginaActual * itemsPorPagina;
  const indexPrimerItem = indexUltimoItem - itemsPorPagina;
  const incidentesActuales = incidentes.slice(indexPrimerItem, indexUltimoItem);
  const totalPaginas = Math.ceil(incidentes.length / itemsPorPagina);

  const getEstadoBadge = (estado) => {
    const base = {padding:'3px 10px',borderRadius:'4px',fontSize:'11px',fontWeight:'700',letterSpacing:'0.5px',textShadow:'0 1px 2px rgba(0,0,0,0.15)',border:'1px solid rgba(255,255,255,0.3)'};
    switch (estado) {
      case 'pat': return <span style={{...base,backgroundColor:'#f59f00',color:'#fff'}}>Pendiente</span>;
      case 'ate': return <span style={{...base,backgroundColor:'#206bc4',color:'#fff'}}>En Atención</span>;
      case 'cer': return <span style={{...base,backgroundColor:'#2fb344',color:'#fff'}}>Cerrado</span>;
      default: return <span className="tbl-badge bg-secondary-lt">{estado}</span>;
    }
  };

  const getGravedadBadge = (gravedad) => {
    const base = {padding:'3px 10px',borderRadius:'4px',fontSize:'11px',fontWeight:'700',letterSpacing:'0.5px',textShadow:'0 1px 2px rgba(0,0,0,0.15)',border:'1px solid rgba(255,255,255,0.3)'};
    switch (gravedad) {
      case 'lev': return <span style={{...base,backgroundColor:'#2fb344',color:'#fff'}}>Leve</span>;
      case 'mod': return <span style={{...base,backgroundColor:'#f76707',color:'#fff'}}>Moderada</span>;
      case 'gra': return <span style={{...base,backgroundColor:'#d63939',color:'#fff'}}>Grave</span>;
      default: return <span className="tbl-badge bg-secondary-lt">{gravedad}</span>;
    }
  };

  return (
    <div className="tbl-page-wrapper">
      <div className="tbl-page-header">
        <div className="tbl-row align-items-center">
          <div className="tbl-col">
            <div className="tbl-page-pretitle">Gestión de Campo</div>
            <h2 className="tbl-page-title">Incidentes y Reportes</h2>
          </div>
          <div className="tbl-col-auto">
            <button className="tbl-btn tbl-btn-primary" onClick={obtenerIncidentes} disabled={cargando}>
              <FaSyncAlt className={cargando ? 'icon-spin' : ''} style={{marginRight: '8px'}} /> {cargando ? 'Cargando...' : 'Actualizar Datos'}
            </button>
          </div>
        </div>
      </div>

      <div className="tbl-page-body">
        {cargando ? <div className="tbl-empty">Cargando datos...</div> 
        : incidentes.length === 0 ? <div className="tbl-empty">No hay incidentes registrados.</div> 
        : (
          <>
            <div className="tbl-row-cards">
              {incidentesActuales.map(inc => (
                <div className="tbl-card" key={inc.id}>
                  <div className="tbl-card-img-top" onClick={() => verEvidencias(inc)} style={{cursor:'pointer',position:'relative'}} title="Ver evidencias">
                    {inc.imagenUrl ? <img src={inc.imagenUrl} alt="Evidencia" /> : <div className="tbl-img-placeholder"><FaCamera size={24} /><span>Sin Evidencia</span></div>}
                    <div style={{position:'absolute',top:0,left:0,right:0,height:'50px',background:'linear-gradient(to bottom, rgba(0,0,0,0.55), transparent)',borderRadius:'4px 4px 0 0',pointerEvents:'none'}}></div>
                    <div className="tbl-card-badges" style={{position:'absolute',top:'8px',left:'8px',display:'flex',gap:'4px',zIndex:1}}>{getEstadoBadge(inc.estado)}{getGravedadBadge(inc.gravedad)}</div>
                    {(inc.imagesCount > 0 || inc.videosCount > 0) && (
                      <div style={{position:'absolute',bottom:'8px',right:'8px',background:'rgba(0,0,0,0.6)',color:'#fff',padding:'3px 8px',borderRadius:'12px',fontSize:'11px',display:'flex',alignItems:'center',gap:'6px'}}>
                        {inc.imagesCount > 0 && <span><FaImage size={10}/> {inc.imagesCount}</span>}
                        {inc.videosCount > 0 && <span><FaVideo size={10}/> {inc.videosCount}</span>}
                      </div>
                    )}
                  </div>
                  <div className="tbl-card-body">
                    <h3 className="tbl-card-title">{inc.tipo}</h3>
                    <div className="tbl-text-muted tbl-mb-2"><FaMapMarkerAlt className="tbl-icon tbl-text-blue" /><strong>{inc.codigo}</strong><br/><span style={{paddingLeft: '20px', fontSize: '0.85rem'}}>{inc.lugar}</span></div>
                    <div className="tbl-text-muted"><FaCalendarAlt className="tbl-icon" /> {inc.fecha}</div>
                  </div>
                  <div className="tbl-card-footer">
                    <div className="tbl-media-icons">{inc.imagesCount > 0 && <span title="Fotos"><FaImage /> {inc.imagesCount}</span>}{inc.videosCount > 0 && <span title="Videos"><FaVideo /> {inc.videosCount}</span>}</div>
                    <div className="tbl-avatar-group" title={`Registrado por ${inc.usuario}`}>
                      <FaUser style={{ fontSize: '11px', color: '#64748b', marginRight: '5px' }} />
                      <span className="tbl-avatar-text">{inc.usuario}</span>
                    </div>
                  </div>
                  <div className="tbl-card-btn-bottom" onClick={() => abrirModal(inc)}><FaEye /> Gestionar / Parte Diario</div>
                </div>
              ))}
            </div>
            <div className="tbl-pagination-wrapper">
              <span className="tbl-text-muted">Mostrando página {paginaActual} de {totalPaginas}</span>
              <ul className="tbl-pagination">
                <li className={`tbl-page-item ${paginaActual === 1 ? 'disabled' : ''}`} onClick={() => setPaginaActual(p => Math.max(1, p - 1))}><button className="tbl-page-link"><FaChevronLeft /></button></li>
                <li className={`tbl-page-item ${paginaActual === totalPaginas ? 'disabled' : ''}`} onClick={() => setPaginaActual(p => Math.min(totalPaginas, p + 1))}><button className="tbl-page-link"><FaChevronRight /></button></li>
              </ul>
            </div>
          </>
        )}
      </div>

      {/* ── MODAL PRINCIPAL (GESTIÓN) ──────────────────────────────────── */}
      {modalAbierto && incidenteActivo && (
        <div className="tbl-modal-backdrop" onClick={() => setModalAbierto(false)}>
          <div className="tbl-modal-dialog" onClick={e => e.stopPropagation()} style={{maxWidth: '960px'}}>
            <div className="tbl-modal-content">
              <div className="tbl-modal-header">
                <h5 className="tbl-modal-title">Gestión de Incidente #{incidenteActivo.id}</h5>
                <button className="tbl-btn-close" onClick={() => setModalAbierto(false)}><FaTimes/></button>
              </div>
              <div className="tbl-modal-body">
                <div className="tbl-alert tbl-alert-info">
                  <h4 className="tbl-alert-title">{incidenteActivo.tipo} en {incidenteActivo.codigo}</h4>
                  <div className="tbl-text-muted">{incidenteActivo.lugar}</div>
                </div>
                <div className="tbl-row tbl-mb-3 align-items-center">
                  <div className="tbl-col-3">
                    <label className="tbl-form-label">Tipo de Recurso</label>
                    <select className="tbl-form-select" value={nuevoRecurso.tipo} onChange={e => setNuevoRecurso({...nuevoRecurso, tipo: e.target.value})}>
                      <option value="Personal">Personal (HH / Día)</option>
                      <option value="Maquinaria">Maquinaria (HE / Día)</option>
                      <option value="Insumo">Insumos / Materiales</option>
                    </select>
                  </div>
                </div>

                {nuevoRecurso.tipo === 'Maquinaria' ? (
                  <div style={{ background: '#f8fafc', padding: '20px', borderRadius: '4px', border: '1px solid #e2e8f0', marginBottom: '15px' }}>
                    <div style={{ display:'flex', alignItems:'center', gap:'8px', marginBottom:'20px', color:'#206bc4', fontWeight:'bold', fontSize:'16px' }}><FaFileInvoice /> Formulario: Parte Diario de Maquinaria</div>
                    <div className="tbl-row tbl-mb-3">
                      <div className="tbl-col"><label className="tbl-form-label">N° de Parte <span style={{color:'red'}}>*</span></label><input type="text" className="tbl-form-control" value={nuevoRecurso.numeroParte} onChange={e => setNuevoRecurso({...nuevoRecurso, numeroParte: e.target.value})} style={{fontWeight: 'bold', backgroundColor: '#f1f5f9'}}/></div>
                      <div className="tbl-col"><label className="tbl-form-label">Fecha</label><input type="date" className="tbl-form-control" value={nuevoRecurso.fechaParte} onChange={e => setNuevoRecurso({...nuevoRecurso, fechaParte: e.target.value})} /></div>
                      <div className="tbl-col"><label className="tbl-form-label">Turno</label><select className="tbl-form-select" value={nuevoRecurso.turno} onChange={e => setNuevoRecurso({...nuevoRecurso, turno: e.target.value})}><option value="Día">Día</option><option value="Noche">Noche</option></select></div>
                      <div className="tbl-col"><label className="tbl-form-label">Zona de Trabajo</label><input type="text" className="tbl-form-control" placeholder="Ej. Tramo 15" value={nuevoRecurso.zonaTrabajo} onChange={e => setNuevoRecurso({...nuevoRecurso, zonaTrabajo: e.target.value})} /></div>
                    </div>
                    <div className="tbl-row tbl-mb-3">
                      <div className="tbl-col"><label className="tbl-form-label">Proveedor</label><input type="text" className="tbl-form-control" placeholder="Nombre de empresa" value={nuevoRecurso.proveedor} onChange={e => setNuevoRecurso({...nuevoRecurso, proveedor: e.target.value})} /></div>
                      <div className="tbl-col"><label className="tbl-form-label">Operador</label><input type="text" className="tbl-form-control" placeholder="Nombre del operador" value={nuevoRecurso.operador} onChange={e => setNuevoRecurso({...nuevoRecurso, operador: e.target.value})} /></div>
                    </div>
                    <div className="tbl-row tbl-mb-3">
                      <div className="tbl-col-4"><label className="tbl-form-label">Licencia</label><input type="text" className="tbl-form-control" placeholder="N° de licencia" value={nuevoRecurso.licencia} onChange={e => setNuevoRecurso({...nuevoRecurso, licencia: e.target.value})} /></div>
                      <div className="tbl-col-4"><label className="tbl-form-label">Categoría</label><input type="text" className="tbl-form-control" placeholder="Ej. A-IIIb" value={nuevoRecurso.categoria} onChange={e => setNuevoRecurso({...nuevoRecurso, categoria: e.target.value})} /></div>
                    </div>
                    <div className="tbl-row tbl-mb-3">
                      <div className="tbl-col-3">
                        <label className="tbl-form-label">Origen <button type="button" onClick={() => setMantenedorAbierto(true)} title="Gestionar catálogos" style={{ background:'none', border:'none', color:'#206bc4', cursor:'pointer', fontSize:'11px', padding:'0 0 0 4px' }}><FaPlus /> gestionar</button></label>
                        <select className="tbl-form-select" value={nuevoRecurso.origen} onChange={e => onCambiaOrigen(e.target.value)}>
                          <option value="JURP">JURP (propia)</option>
                          <option value="EXTERNA">Externa</option>
                        </select>
                      </div>
                      <div className="tbl-col-3">
                        <label className="tbl-form-label">Equipo</label>
                        <select className="tbl-form-select" value={nuevoRecurso.equipoId} onChange={e => onCambiaEquipo(e.target.value)}>
                          <option value="">— Seleccionar —</option>
                          {catEquipos.map(eq => <option key={eq.id} value={eq.id}>{eq.nombre}</option>)}
                        </select>
                      </div>
                      <div className="tbl-col-3">
                        <label className="tbl-form-label">Marca</label>
                        <select className="tbl-form-select" value={nuevoRecurso.marcaId} onChange={e => onCambiaMarca(e.target.value)} disabled={!nuevoRecurso.equipoId}>
                          <option value="">{nuevoRecurso.equipoId ? '— Seleccionar —' : 'Elige equipo'}</option>
                          {catMarcas.map(ma => <option key={ma.id} value={ma.id}>{ma.nombre}</option>)}
                        </select>
                      </div>
                      <div className="tbl-col-3">
                        <label className="tbl-form-label">Modelo/Placa {nuevoRecurso.codigoMaquina && <span style={{color:'#1a5aa8',fontWeight:700,fontSize:'11px'}}>· {nuevoRecurso.codigoMaquina}</span>}</label>
                        <select className="tbl-form-select" value={nuevoRecurso.modeloId} onChange={e => onCambiaModelo(e.target.value)} disabled={!nuevoRecurso.marcaId}>
                          <option value="">{nuevoRecurso.marcaId ? '— Seleccionar —' : 'Elige marca'}</option>
                          {catModelos.map(mo => <option key={mo.id} value={mo.id}>{mo.codigo} · {mo.placa ? `${mo.modelo || ''} · ${mo.placa}` : (mo.modelo || 's/modelo')}</option>)}
                        </select>
                      </div>
                    </div>
                    <div className="tbl-row tbl-mb-3">
                      <div className="tbl-col-3"><label className="tbl-form-label">Precio Unit. (S/ HE)</label><input type="number" className="tbl-form-control" value={nuevoRecurso.precioUnitario} onChange={e => setNuevoRecurso({...nuevoRecurso, precioUnitario: e.target.value})} /></div>
                    </div>
                    <div className="tbl-row tbl-mb-3">
                      <div className="tbl-col"><label className="tbl-form-label">HM Inicio <span style={{color:'red'}}>*</span></label><input type="number" step="0.1" className="tbl-form-control" value={nuevoRecurso.hmInicio} onChange={e => setNuevoRecurso({...nuevoRecurso, hmInicio: e.target.value})} /></div>
                      <div className="tbl-col"><label className="tbl-form-label">HM Fin <span style={{color:'red'}}>*</span></label><input type="number" step="0.1" className="tbl-form-control" value={nuevoRecurso.hmFin} onChange={e => setNuevoRecurso({...nuevoRecurso, hmFin: e.target.value})} /></div>
                      <div className="tbl-col-auto" style={{display: 'flex', flexDirection: 'column', justifyContent: 'flex-end'}}><div style={{background: '#e0f2fe', color: '#0284c7', padding: '8px 12px', borderRadius: '4px', fontWeight: 'bold', fontSize: '13px', border: '1px solid #bae6fd'}}>Horas: {horasMaquina} h</div></div>
                      <div className="tbl-col"><label className="tbl-form-label">Combustible (Gls)</label><input type="number" className="tbl-form-control" value={nuevoRecurso.combustible} onChange={e => setNuevoRecurso({...nuevoRecurso, combustible: e.target.value})} /></div>
                      <div className="tbl-col"><label className="tbl-form-label">Vale N°</label><input type="text" className="tbl-form-control" value={nuevoRecurso.vale} onChange={e => setNuevoRecurso({...nuevoRecurso, vale: e.target.value})} /></div>
                    </div>
                    {(() => {
                      const totalHM = parseFloat(horasMaquina) || 0;
                      const efectivas = nuevoRecurso.horasEfectivas === '' ? totalHM : parseFloat(nuevoRecurso.horasEfectivas)||0;
                      const hayReduccion = efectivas < totalHM;
                      return (
                        <div className="tbl-row tbl-mb-3">
                          <div className="tbl-col-3">
                            <label className="tbl-form-label">Horas Efectivas (HE)</label>
                            <input type="number" min="0" max={totalHM} step="0.1" className="tbl-form-control"
                              placeholder={String(totalHM)}
                              value={nuevoRecurso.horasEfectivas}
                              onChange={e => setNuevoRecurso({...nuevoRecurso, horasEfectivas: e.target.value})}
                              style={hayReduccion ? {borderColor:'#f59e0b', backgroundColor:'#fffbeb', fontWeight:'bold'} : {fontWeight:'bold'}}
                              title="Por defecto = horas del horómetro. Edítalo si fueron menos." />
                          </div>
                          <div className="tbl-col">
                            <label className="tbl-form-label">
                              Observación {hayReduccion ? <span style={{color:'#d97706',fontSize:'11px',fontWeight:600}}>· requerida (reducción de {(totalHM - efectivas).toFixed(1)} HE)</span> : <span style={{color:'#94a3b8',fontSize:'11px'}}>· opcional</span>}
                            </label>
                            <input type="text" className="tbl-form-control"
                              placeholder={hayReduccion ? 'Detalla el motivo de la reducción de horas...' : 'Sin observaciones de reducción'}
                              value={nuevoRecurso.obsReduccion}
                              onChange={e => setNuevoRecurso({...nuevoRecurso, obsReduccion: e.target.value})}
                              style={hayReduccion && !nuevoRecurso.obsReduccion.trim() ? {borderColor:'#f59e0b', backgroundColor:'#fffbeb'} : {}} />
                          </div>
                        </div>
                      );
                    })()}
                    <div className="tbl-row tbl-mb-3">
                      <div className="tbl-col"><label className="tbl-form-label">Actividades Realizadas <span style={{color:'red'}}>*</span></label>
                        <select className="tbl-form-select" value={nuevoRecurso.actividad} onChange={e => onCambiaActividad(e.target.value)}>
                          <option value="">— Seleccionar actividad —</option>
                          {catActividades.map(a => <option key={a.id} value={a.nombre}>{a.nombre}</option>)}
                          {/* Si la actividad actual no está en el catálogo (viene de un parte viejo), la mostramos igual */}
                          {nuevoRecurso.actividad && !catActividades.some(a => a.nombre === nuevoRecurso.actividad) && <option value={nuevoRecurso.actividad}>{nuevoRecurso.actividad}</option>}
                          <option value="__OTRO__">➕ Otro (agregar nueva)...</option>
                        </select>
                      </div>
                      <div className="tbl-col"><label className="tbl-form-label">Observaciones</label><input type="text" className="tbl-form-control" placeholder="Condiciones del terreno, clima..." value={nuevoRecurso.observaciones} onChange={e => setNuevoRecurso({...nuevoRecurso, observaciones: e.target.value})} /></div>
                    </div>

                    {/* ── Cálculo de metrado (opcional) ──────────────────────── */}
                    <div style={{ background:'#fff', border:'1px solid #e2e8f0', borderRadius:'6px', padding:'14px', marginTop:'4px' }}>
                      <label style={{ display:'flex', alignItems:'center', gap:'8px', cursor:'pointer', fontWeight:600, color:'#1e293b' }}>
                        <input type="checkbox" checked={nuevoRecurso.incluirMetrado} onChange={e => setNuevoRecurso({...nuevoRecurso, incluirMetrado: e.target.checked})} />
                        Incluir cálculo de metrado (volumen extraído)
                      </label>

                      {nuevoRecurso.incluirMetrado && (
                        <div style={{ marginTop:'14px' }}>
                          <div className="tbl-row tbl-mb-3">
                            {/* Longitud */}
                            <div className="tbl-col-3">
                              <label className="tbl-form-label">Longitud L (m)</label>
                              <input type="number" step="0.01" className="tbl-form-control" placeholder="0.00" value={nuevoRecurso.longitud} onChange={e => setNuevoRecurso({...nuevoRecurso, longitud: e.target.value})} />
                            </div>
                            {/* Altura con thumbnail */}
                            <div className="tbl-col-3">
                              <label className="tbl-form-label" style={{display:'flex',alignItems:'center',gap:'6px'}}>
                                Altura H (m)
                                <img src={refAltura} alt="Ref. altura" onClick={() => setImgRefModal({src: refAltura, titulo: 'Referencia: Altura (H)'})} style={{height:'24px',width:'40px',objectFit:'cover',borderRadius:'3px',cursor:'pointer',border:'1px solid #cbd5e1'}} title="Ver referencia de altura" />
                              </label>
                              <input type="number" step="0.01" className="tbl-form-control" placeholder="0.00" value={nuevoRecurso.altura} onChange={e => setNuevoRecurso({...nuevoRecurso, altura: e.target.value})} />
                            </div>
                            {/* Ancho Superior con thumbnail */}
                            <div className="tbl-col-3">
                              <label className="tbl-form-label" style={{display:'flex',alignItems:'center',gap:'6px'}}>
                                Ancho Sup. Ws (m)
                                <img src={refAncho} alt="Ref. ancho" onClick={() => setImgRefModal({src: refAncho, titulo: 'Referencia: Ancho Superior (Ws) - Ancho Inferior (Wi)'})} style={{height:'24px',width:'40px',objectFit:'cover',borderRadius:'3px',cursor:'pointer',border:'1px solid #cbd5e1'}} title="Ver referencia de anchos" />
                              </label>
                              <input type="number" step="0.01" className="tbl-form-control" placeholder="0.00" value={nuevoRecurso.anchoSup} onChange={e => setNuevoRecurso({...nuevoRecurso, anchoSup: e.target.value})} />
                            </div>
                            {/* Ancho Inferior con thumbnail */}
                            <div className="tbl-col-3">
                              <label className="tbl-form-label" style={{display:'flex',alignItems:'center',gap:'6px'}}>
                                Ancho Inf. Wi (m)
                                <img src={refAncho} alt="Ref. ancho" onClick={() => setImgRefModal({src: refAncho, titulo: 'Referencia: Ancho Superior (Ws) - Ancho Inferior (Wi)'})} style={{height:'24px',width:'40px',objectFit:'cover',borderRadius:'3px',cursor:'pointer',border:'1px solid #cbd5e1'}} title="Ver referencia de anchos" />
                              </label>
                              <input type="number" step="0.01" className="tbl-form-control" placeholder="0.00" value={nuevoRecurso.anchoInf} onChange={e => setNuevoRecurso({...nuevoRecurso, anchoInf: e.target.value})} />
                            </div>
                          </div>
                          <div style={{ display:'flex', alignItems:'center', gap:'10px', background:'#f0f9ff', borderRadius:'6px', padding:'10px 14px', fontSize:'13px' }}>
                            <span style={{color:'#64748b'}}>Fórmula: V = (Ws + Wi / 2) × H × L</span>
                            <span style={{marginLeft:'auto', fontWeight:'bold', color:'#0284c7', fontSize:'15px'}}>Volumen extraído: {volumenMetrado} m³</span>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                ) : nuevoRecurso.tipo === 'Personal' ? (
                  <>
                  <div className="tbl-row tbl-mb-3">
                    <div className="tbl-col-3"><label className="tbl-form-label">Cargo</label><input type="text" className="tbl-form-control" placeholder="Ej. Peón, Operario..." value={nuevoRecurso.descripcion} onChange={e => setNuevoRecurso({...nuevoRecurso, descripcion: e.target.value})} /></div>
                    <div className="tbl-col-2"><label className="tbl-form-label">N° Personas</label><input type="number" min="1" className="tbl-form-control" value={nuevoRecurso.numPersonas} onChange={e => setNuevoRecurso({...nuevoRecurso, numPersonas: e.target.value})} /></div>
                    <div className="tbl-col-2"><label className="tbl-form-label">H. Normales</label><input type="number" min="0" className="tbl-form-control" value={nuevoRecurso.horasTrabajo} onChange={e => setNuevoRecurso({...nuevoRecurso, horasTrabajo: e.target.value})} /></div>
                    <div className="tbl-col-2"><label className="tbl-form-label">H. Extras</label><input type="number" min="0" className="tbl-form-control" value={nuevoRecurso.horasExtras} onChange={e => setNuevoRecurso({...nuevoRecurso, horasExtras: e.target.value})} /></div>
                    <div className="tbl-col-2"><label className="tbl-form-label">S/ por HH</label><input type="number" className="tbl-form-control" value={nuevoRecurso.precioUnitario} onChange={e => setNuevoRecurso({...nuevoRecurso, precioUnitario: e.target.value})} /></div>
                    <div className="tbl-col-1"><label className="tbl-form-label">Total</label><input type="text" className="tbl-form-control" disabled value={((parseInt(nuevoRecurso.numPersonas)||0) * ((parseFloat(nuevoRecurso.horasTrabajo)||0) + (parseFloat(nuevoRecurso.horasExtras)||0))) || 0} style={{backgroundColor: '#e0f2fe', color: '#0284c7', fontWeight: 'bold'}} title="Total HH teóricas" /></div>
                  </div>
                  </>
                ) : (
                  <div className="tbl-row tbl-mb-3">
                    <div className="tbl-col"><label className="tbl-form-label">Descripción del Insumo</label><input type="text" className="tbl-form-control" placeholder="Ej. Piedra chancada, Cemento..." value={nuevoRecurso.descripcion} onChange={e => setNuevoRecurso({...nuevoRecurso, descripcion: e.target.value})} /></div>
                    <div className="tbl-col-2"><label className="tbl-form-label">Cant.</label><input type="number" className="tbl-form-control" value={nuevoRecurso.cantidad} onChange={e => setNuevoRecurso({...nuevoRecurso, cantidad: e.target.value})} /></div>
                    <div className="tbl-col-2"><label className="tbl-form-label">Precio Unit. (S/)</label><input type="number" className="tbl-form-control" value={nuevoRecurso.precioUnitario} onChange={e => setNuevoRecurso({...nuevoRecurso, precioUnitario: e.target.value})} /></div>
                  </div>
                )}
                
                <div style={{display: 'flex', justifyContent: 'flex-end', marginBottom: '20px'}}>
                  <button className="tbl-btn tbl-btn-success" onClick={agregarRecurso}><FaPlus style={{marginRight:'5px'}}/> Agregar a la lista</button>
                </div>
                <div className="tbl-table-responsive tbl-border-top">
                  <table className="tbl-table tbl-table-vcenter">
                    <thead><tr><th>Tipo</th><th>Detalle (Resumen)</th><th className="tbl-text-end">Cantidad</th><th className="tbl-text-end">P. Unit.</th><th className="tbl-text-end">Total</th><th></th></tr></thead>
                    <tbody>
                      {recursos.length === 0 ? <tr><td colSpan="6" className="tbl-text-center tbl-text-muted py-4">Aún no hay registros para este incidente.</td></tr> : (
                        recursosAgrupados.map(r => (
                          <tr key={r.idLocal}>
                            <td><span className="tbl-badge bg-secondary-lt">{r.tipo}</span></td>
                            <td style={{fontSize: '11px', whiteSpace: 'pre-wrap', maxWidth: '400px', lineHeight: '1.4'}}>
                              {r.tipo === 'Maquinaria' && r.count > 1
                                ? (r.descripcionResumen || '').replace(/Parte N° [^|]*\|\s*/i, '').trim()
                                : r.tipo === 'Personal' && r.count > 1
                                ? `${r.descripcion} (Cuadrilla: ${r.numPersonas} persona(s) x ${r.horasTrabajo}h normales + ${r.horasExtras}h extras)`
                                : (r.descripcionResumen || r.descripcion)}
                              {r.count > 1 && <span style={{marginLeft:'6px', backgroundColor:'#e0f2fe', color:'#0284c7', fontWeight:'bold', fontSize:'10px', padding:'1px 6px', borderRadius:'10px'}}>×{r.count}</span>}
                            </td>
                            <td className="tbl-text-end font-bold">{r.cantidadTotal.toFixed(r.tipo==='Personal'?1:2)} <span style={{fontSize: '10px', marginLeft: '4px', color: '#626976'}}>{r.tipo === 'Personal' ? 'HH' : r.tipo === 'Maquinaria' ? 'HE' : 'Unid.'}</span></td>
                            <td className="tbl-text-end">S/ {parseFloat(r.precioUnitario).toFixed(2)}</td>
                            <td className="tbl-text-end text-blue font-bold">S/ {r.totalSum.toFixed(2)}</td>
                            <td>
                              {r.guardadoEnDB ? (
                                <div style={{display: 'flex', gap: '6px', alignItems: 'center', flexWrap:'wrap'}}>
                                  {r.tipo === 'Maquinaria' && r.count > 1
                                    ? (() => {
                                        const cerrados = r.partesMaq.filter(p => p.cerrado).length;
                                        const activos = r.count - cerrados;
                                        return <span className="tbl-badge" style={{backgroundColor:'#e0f2fe', color:'#0284c7', fontWeight:600}}>{activos > 0 ? `${activos} activo${activos>1?'s':''}` : ''}{activos > 0 && cerrados > 0 ? ' · ' : ''}{cerrados > 0 ? `${cerrados} cerrado${cerrados>1?'s':''}` : ''}</span>;
                                      })()
                                    : r.tipo === 'Maquinaria' && r.cerrado
                                    ? <span className="tbl-badge" style={{backgroundColor:'#e2e8f0', color:'#475569'}}>Cerrado</span>
                                    : <span className="tbl-badge bg-green-lt">Guardado{r.count > 1 ? ` (${r.count})` : ''}</span>}
                                  {r.tipo === 'Maquinaria' && r.count === 1 && (<button type="button" onClick={() => abrirModalPdf(r.dbId)} className="tbl-btn-action text-blue" title="Ver Parte Diario (PDF)" style={{padding: '4px 8px', backgroundColor: '#e0f2fe', borderRadius: '4px', border: 'none', cursor: 'pointer', display: 'inline-flex'}}><FaFilePdf size={16} /></button>)}
                                  {r.tipo === 'Maquinaria' && r.count === 1 && !r.cerrado && (<button type="button" onClick={() => cerrarParteDiario(r)} className="tbl-btn-action" title="Finalizar actividades (libera la máquina)" style={{padding: '4px 10px', backgroundColor: '#dcfce7', color:'#15803d', borderRadius: '4px', border: 'none', cursor: 'pointer', display: 'inline-flex', alignItems:'center', gap:'4px', fontSize:'12px', fontWeight:'600'}}><FaCheckCircle size={13} /> Finalizar</button>)}
                                  {r.tipo === 'Maquinaria' && r.count > 1 && (
                                    <div style={{display:'flex', flexDirection:'column', gap:'4px', width:'100%'}}>
                                      {r.partesMaq.map((p, idx) => (
                                        <div key={p.idLocal || idx} style={{display:'flex', alignItems:'center', gap:'4px', justifyContent:'flex-end'}}>
                                          <span style={{fontSize:'11px', color:'#64748b', marginRight:'auto'}}>{p.numeroParte}{p.cerrado && <span style={{color:'#15803d', fontWeight:600}}> · Cerrado</span>}</span>
                                          {p.dbId && <button type="button" onClick={() => abrirModalPdf(p.dbId)} title="Ver PDF" style={{padding:'3px 7px', backgroundColor:'#e0f2fe', borderRadius:'4px', border:'none', cursor:'pointer', display:'inline-flex'}}><FaFilePdf size={14} /></button>}
                                          {!p.cerrado && <button type="button" onClick={() => cerrarParteDiario(p.registro)} title="Finalizar este parte" style={{padding:'3px 8px', backgroundColor:'#dcfce7', color:'#15803d', borderRadius:'4px', border:'none', cursor:'pointer', display:'inline-flex', alignItems:'center', gap:'3px', fontSize:'11px', fontWeight:600}}><FaCheckCircle size={11} /> Finalizar</button>}
                                        </div>
                                      ))}
                                    </div>
                                  )}
                                  {!(r.tipo === 'Maquinaria' && r.cerrado) && (<button type="button" onClick={() => eliminarRecursoGuardado(r)} className="tbl-btn-action text-danger" title={r.count > 1 ? `Eliminar los ${r.count} registros` : 'Eliminar de la base'} style={{padding: '4px 8px', backgroundColor: '#fee2e2', borderRadius: '4px', border: 'none', cursor: 'pointer', display: 'inline-flex'}}><FaTrash size={14} /></button>)}
                                </div>
                              ) : (<button className="tbl-btn-action text-danger" onClick={() => eliminarRecursosLocales(r.idsLocales)} title="Eliminar"><FaTimes/></button>)}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
              <div className="tbl-modal-footer" style={{flexWrap:'wrap',gap:'8px'}}>
                <div className="tbl-text-start tbl-text-muted">Costo Total: <span style={{fontSize: '1.25rem', color: '#1e293b', fontWeight: 'bold'}}>S/ {costoTotalIncidente.toFixed(2)}</span></div>
                <div style={{display:'flex',gap:'8px',alignItems:'center',flexWrap:'wrap'}}>
                  {incidenteActivo?.estado === 'cer' ? (
                    <span style={{background:'#dcfce7',color:'#15803d',padding:'6px 14px',borderRadius:'4px',fontSize:'13px',fontWeight:'600',display:'flex',alignItems:'center',gap:'6px'}}><FaCheckCircle/> Incidencia cerrada</span>
                  ) : (
                    <button className="tbl-btn" onClick={cerrarIncidenteCompleto} style={{background:'#2fb344',color:'#fff',border:'none',padding:'6px 14px',borderRadius:'4px',cursor:'pointer',fontSize:'13px',display:'flex',alignItems:'center',gap:'6px'}} title="Cierra los partes, libera las máquinas y marca la incidencia como cerrada"><FaCheckCircle/> Cerrar incidencia</button>
                  )}
                  <button className="tbl-btn" onClick={exportarPDF} style={{background:'#d63939',color:'#fff',border:'none',padding:'6px 14px',borderRadius:'4px',cursor:'pointer',fontSize:'13px',display:'flex',alignItems:'center',gap:'6px'}} title="Descargar PDF"><FaFilePdf/> PDF</button>
                  <button className="tbl-btn" onClick={exportarExcel} style={{background:'#2fb344',color:'#fff',border:'none',padding:'6px 14px',borderRadius:'4px',cursor:'pointer',fontSize:'13px',display:'flex',alignItems:'center',gap:'6px'}} title="Descargar Excel"><FaFileExcel/> Excel</button>
                  <button className="tbl-btn tbl-btn-link" onClick={() => setModalAbierto(false)}>Cerrar</button>
                  <button className="tbl-btn tbl-btn-primary" onClick={guardarCosteos} disabled={guardando}>{guardando ? <><FaSyncAlt className="icon-spin" style={{marginRight: '8px'}} /> Guardando...</> : <><FaSave style={{marginRight: '8px'}} /> Guardar Costeos</>}</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── MODAL PDF ──────────────────────────────────────────────────── */}
      {/* ── Modal de imagen de referencia (metrado) ────────────────────── */}
      {imgRefModal && (
        <div onClick={() => setImgRefModal(null)} style={{ position:'fixed', inset:0, zIndex:10001, background:'rgba(0,0,0,0.8)', display:'flex', alignItems:'center', justifyContent:'center', padding:'20px' }}>
          <div onClick={e => e.stopPropagation()} style={{ background:'#fff', borderRadius:'10px', overflow:'hidden', maxWidth:'1000px', width:'100%', maxHeight:'90vh', display:'flex', flexDirection:'column' }}>
            <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'14px 18px', background:'#f8fafc', borderBottom:'1px solid #e2e8f0' }}>
              <h5 style={{ margin:0, fontSize:'15px', color:'#1e293b' }}>{imgRefModal.titulo}</h5>
              <button onClick={() => setImgRefModal(null)} style={{ background:'none', border:'none', cursor:'pointer', color:'#64748b', fontSize:'18px', display:'flex' }}><FaTimes /></button>
            </div>
            <div style={{ padding:'16px', overflow:'auto', textAlign:'center' }}>
              <img src={imgRefModal.src} alt={imgRefModal.titulo} style={{ maxWidth:'100%', height:'auto' }} />
            </div>
          </div>
        </div>
      )}

      {modalPdfAbierto && (
        <div className="tbl-modal-backdrop" onClick={() => setModalPdfAbierto(false)} style={{ zIndex: 9999, backgroundColor: 'rgba(0,0,0,0.75)' }}>
          <div className="tbl-modal-dialog" onClick={e => e.stopPropagation()} style={{ maxWidth: '850px', height: '90vh', display: 'flex', flexDirection: 'column', position: 'relative', zIndex: 10000, marginTop: '2vh' }}>
            <div className="tbl-modal-content" style={{ flex: 1, display: 'flex', flexDirection: 'column', boxShadow: '0 0 20px rgba(0,0,0,0.5)' }}>
              <div className="tbl-modal-header" style={{ borderBottom: '1px solid #e2e8f0', padding: '15px 20px', backgroundColor: '#f8fafc' }}>
                <h5 className="tbl-modal-title" style={{ display: 'flex', alignItems: 'center', gap: '8px' }}><FaFilePdf color="#dc2626" /> Visor de Documento PDF</h5>
                <button className="tbl-btn-close" onClick={() => setModalPdfAbierto(false)}><FaTimes/></button>
              </div>
              <div className="tbl-modal-body" style={{ flex: 1, padding: 0, overflow: 'hidden', backgroundColor: '#525659' }}>
                <iframe src={pdfUrlActivo} style={{ width: '100%', height: '100%', border: 'none' }} title="Visor PDF" />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── MODAL GALERÍA DE EVIDENCIAS ────────────────────────────────── */}
      {modalMediaAbierto && (
        <div onClick={() => setModalMediaAbierto(false)} style={{ position:'fixed',top:0,left:0,right:0,bottom:0,zIndex:10001,background:'rgba(0,0,0,0.92)',display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center' }}>
          {/* Botón cerrar */}
          <button onClick={() => setModalMediaAbierto(false)} style={{ position:'absolute',top:'16px',right:'20px',background:'rgba(255,255,255,0.15)',border:'none',color:'#fff',fontSize:'22px',cursor:'pointer',borderRadius:'50%',width:'40px',height:'40px',display:'flex',alignItems:'center',justifyContent:'center',zIndex:10002 }}>✕</button>

          {/* Header con info del incidente */}
          {galeriaIncidente && (
            <div onClick={e=>e.stopPropagation()} style={{ color:'#fff',textAlign:'center',marginBottom:'16px',pointerEvents:'none' }}>
              <div style={{fontSize:'16px',fontWeight:'700'}}>{galeriaIncidente.tipo} — {galeriaIncidente.codigo}</div>
              <div style={{fontSize:'12px',color:'rgba(255,255,255,0.6)',marginTop:'2px'}}>{galeriaIncidente.lugar} · {galeriaIncidente.fecha}</div>
            </div>
          )}

          {cargandoMedia ? (
            <div style={{color:'#fff',fontSize:'14px',display:'flex',alignItems:'center',gap:'8px'}}><FaSyncAlt className="icon-spin"/> Cargando evidencias...</div>
          ) : galeriaMedia.length === 0 ? (
            <div style={{color:'rgba(255,255,255,0.5)',fontSize:'14px'}}>No se encontraron evidencias para este incidente.</div>
          ) : (
            <>
              {/* Media principal */}
              <div onClick={e=>e.stopPropagation()} style={{position:'relative',maxWidth:'90vw',maxHeight:'70vh',display:'flex',alignItems:'center',justifyContent:'center'}}>
                {galeriaMedia[galeriaIndex].type === 'image' ? (
                  <img src={galeriaMedia[galeriaIndex].src} alt="Evidencia" style={{maxWidth:'90vw',maxHeight:'70vh',objectFit:'contain',borderRadius:'8px'}} />
                ) : (
                  <video src={galeriaMedia[galeriaIndex].src} controls autoPlay style={{maxWidth:'90vw',maxHeight:'70vh',borderRadius:'8px',background:'#000'}} />
                )}
              </div>

              {/* Controles de navegación */}
              {galeriaMedia.length > 1 && (
                <div onClick={e=>e.stopPropagation()} style={{display:'flex',alignItems:'center',gap:'16px',marginTop:'16px'}}>
                  <button onClick={galeriaAnterior} disabled={galeriaIndex===0} style={{background:galeriaIndex===0?'rgba(255,255,255,0.1)':'rgba(255,255,255,0.2)',border:'none',color:'#fff',borderRadius:'50%',width:'40px',height:'40px',cursor:galeriaIndex===0?'default':'pointer',display:'flex',alignItems:'center',justifyContent:'center',fontSize:'16px'}}><FaChevronLeft/></button>
                  
                  {/* Thumbnails */}
                  <div style={{display:'flex',gap:'6px',overflowX:'auto',maxWidth:'60vw',padding:'4px'}}>
                    {galeriaMedia.map((m,i) => (
                      <div key={i} onClick={()=>setGaleriaIndex(i)} style={{flexShrink:0,width:'56px',height:'56px',borderRadius:'6px',overflow:'hidden',border:i===galeriaIndex?'2px solid #fff':'2px solid transparent',cursor:'pointer',opacity:i===galeriaIndex?1:0.5,transition:'all 0.2s'}}>
                        {m.type === 'image' ? (
                          <img src={m.src} alt="" style={{width:'100%',height:'100%',objectFit:'cover'}} />
                        ) : (
                          <div style={{width:'100%',height:'100%',background:'#1e293b',display:'flex',alignItems:'center',justifyContent:'center',color:'#fff',fontSize:'18px'}}>▶</div>
                        )}
                      </div>
                    ))}
                  </div>

                  <button onClick={galeriaSiguiente} disabled={galeriaIndex===galeriaMedia.length-1} style={{background:galeriaIndex===galeriaMedia.length-1?'rgba(255,255,255,0.1)':'rgba(255,255,255,0.2)',border:'none',color:'#fff',borderRadius:'50%',width:'40px',height:'40px',cursor:galeriaIndex===galeriaMedia.length-1?'default':'pointer',display:'flex',alignItems:'center',justifyContent:'center',fontSize:'16px'}}><FaChevronRight/></button>
                </div>
              )}

              {/* Contador */}
              <div style={{color:'rgba(255,255,255,0.5)',fontSize:'12px',marginTop:'8px'}}>{galeriaIndex+1} / {galeriaMedia.length} · {galeriaMedia[galeriaIndex].type === 'image' ? 'Foto' : 'Video'}</div>
            </>
          )}
        </div>
      )}

      {/* ── Mantenedor de catálogos (Equipos/Marcas/Modelos) ─────────────── */}
      <MantenedorEquipos
        abierto={mantenedorAbierto}
        onClose={() => { setMantenedorAbierto(false); cargarEquiposCat(nuevoRecurso.origen); if (nuevoRecurso.equipoId) cargarMarcasCat(nuevoRecurso.equipoId); if (nuevoRecurso.marcaId) cargarModelosCat(nuevoRecurso.marcaId); }}
      />

    </div>
  );
}

export default Incidentes;